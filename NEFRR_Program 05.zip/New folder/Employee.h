#ifndef EMPLOYEE
#define EMPLOYEE

#include <string>

using namespace std;
class Employee {
public:
	Employee();//DEFAULT CONSTRUCTOR
//GETTERS AND SETTERS
	string GetName();
	string GetStudentId();
	void SetName( const string& NewName );
	void SetId( const string& NewId );
//VIRTUAL FUCTIONS
	virtual string GetType() const;// RETURNS THE STRING "EMPLOYEE".
	virtual bool ReadData( std::istream& in ) = 0;// TRIES TO RETRIEVE INFO FROM A FILE. RETURNS ISGOOD()
	virtual bool WriteData( std::ostream& out ) = 0; //TRIES TO OUTPUT TO DESKTOP. RETURNS ISGOOD()

protected:
	string name;
	string employeeId;
};
#endif
