#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include "Employee.h"

using namespace std;

Employee::Employee() 
{
    name = "0";
    employeeId = "0";
}
string Employee::GetName() 
{
	return name;
}
string Employee::GetStudentId() 
{
	return employeeId;
}
void Employee::SetName( const string& NewName ) 
{
	name = NewName;
}
void Employee::SetId( const string& NewId ) 
{
	employeeId = NewId;
}
string Employee::GetType() const 
{
	return "Employee";
}
bool Employee::ReadData( std::istream& in )
{
    string NewEmployeeName, NewEmployeeId;
    std:: getline(in, NewEmployeeName);
    std::getline(in, NewEmployeeId);
    SetName(NewEmployeeName);
    SetId(NewEmployeeId);
    return in.good();
}
bool Employee::WriteData(std::ostream& out) 
{
    out << name << endl;
    out << employeeId << endl;
    return out.good();
}