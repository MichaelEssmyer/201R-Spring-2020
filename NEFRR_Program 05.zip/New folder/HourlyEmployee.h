#include "Employee.h"

using namespace std;

class HourlyEmployee: public Employee{
public:
	HourlyEmployee();//DEFAULT CONSTRUCTOR
//GETTERS AND SETTERS
	char GetExpertEmployee() const;
	bool SetExpertEmployee( char NewExpert );
	double GetSalary() const;
	bool SetSalary( double NewSalary );
//VIRTUAL FUNCITION OVERRRIDES
	string GetType() const override;//OVERRIDE FOR EMPLOYEE CLASS FUNCTION
	bool ReadData( std::istream& in ) override; //OVERRIDE FOR EMPLOYEE CLASS FUNCTION
	bool WriteData( std::ostream& out ) override;//OVERRIDE FOR EMPLOYEE CLASS FUNCTION
protected:
	double salary;
	char expertEmployee;
};
