#include <iostream>
#include <fstream>
#include <string>
#include "HourlyEmployee.h"

using namespace std;

HourlyEmployee::HourlyEmployee() //DEFAULT CONSTRUCTOR
{
	salary = -1;
	expertEmployee = '0';
}
char HourlyEmployee::GetExpertEmployee() const 
{
	return expertEmployee;
}
bool HourlyEmployee::SetExpertEmployee( char NewExpert ) //CHECKS EXPERT STATUS. MUST BE EITHER T OR F. SETS EXPERT EMPLOYEE CORRECTLY
{
	expertEmployee = NewExpert;
	if ( ( (expertEmployee != 'T') && (expertEmployee != 't') ) && ( (expertEmployee != 'F')  && (expertEmployee !='f') ) ) {
		return false;
	}
	else {
		expertEmployee = NewExpert;
		return true;
	}
}
double HourlyEmployee::GetSalary() const 
{
	return salary;
}
bool HourlyEmployee::SetSalary( double NewSalary ) //SETS THE SALARY. MUST BE BETWEEN 1000-10,000 INCLUSIVE. 
{
	if (NewSalary >= 1000 && NewSalary <= 10000) {
		salary = NewSalary;
		return true;
	}
	else {
		salary = -1; //WILL GIVE GENERIC VALUE FOR SALARY IF BOUNDARIES NOT MET
		return false;
	}
}
string HourlyEmployee::GetType() const

{
	return "Hourly Employee";
}
bool HourlyEmployee::ReadData( std::istream& in )//READS AND SETS DATA FROM FILE.
{
	Employee::ReadData(in);
	string test;
	char employeeExpertCheck;
	double NewSalary;
	in.get( employeeExpertCheck );//RETRIEVES ONLY CHARACTER FROM THE LINE
	in >> NewSalary;
	in.ignore( std::numeric_limits<std::streamsize>::max(), '\n' );//USES EMPLOYEE VIRTUAL FUNCTION. IGNORES THE EXTRA NEW LINES IF ANY
	SetExpertEmployee( employeeExpertCheck );
	SetSalary( NewSalary );
	return in.good();
}
bool HourlyEmployee::WriteData( std::ostream& out ) //USES EMPLOYEE VIRTUAL FUNCTION. OUTPUTS DATA TO FILE
{
	Employee::WriteData(out);
	out << expertEmployee << endl;
	if (salary == -1) {
		out << "Private. Salary value out of range" << endl;
	}
	else {
		out << GetSalary() << endl;
	}
	return out.good();
}

