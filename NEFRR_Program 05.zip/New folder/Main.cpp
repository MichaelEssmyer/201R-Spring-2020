//NEHESIA EDMOND
//PROGRAM 05
//DUE 2 ARIL

#include <iostream>
#include <array>
#include <fstream>
#include "Employee.h"
#include "HourlyEmployee.h"
#include "MonthlyEmployee.h"

using namespace std;

int main() {
	//CHANGE INPUT or OUTPUT FILE NAME HERE
	string fileName = "input.txt";
	string outputFileName = "output.txt";

	Employee* staff[100];
	for ( int i = 0; i < 100; ++i ) //CREATING ARRAY OF POINTER OBJ. ALL SET TO NULL  INITIALLY
	{
		staff[i] = nullptr;
	}

	//BEGINNING FILE OPENING
	ifstream fileIn;
	fileIn.open( fileName );

	if ( fileIn.fail() ) //PRODUCE ERROR MESSAGE IF FILE DOESNT OPEN. MAKE SURE YOU HAVE TYPED THE FILE NAME CORRECTLY/ FILE IS IN CORRECT LOCATION
	{
		cout << "Input file opening failed\n";
		return 0;
	}
	char characterFlag;
	string lineCheck;//TEMPORARY VARIABLE THAT RETRIEVES ENTIRE LINE FROM FILE
	int indexCounter = 0;//INCREMENTS THE INDEX OF STAFF ARRAY
	int empH_counter = 0;//COUNTS NUMBER OF HOURLY EMPLOYEES FOR DISPLAY LATER
	int empM_counter=0;//COUNTS NUMBER OF MONTHLY EMPLOYEES FOR DISPLAY LATER

	while ( fileIn.good() ) 
	{
		getline( fileIn, lineCheck );
		characterFlag = lineCheck[0];
		if ( (characterFlag == 'h') || (characterFlag == 'H') )//CHECKS IF FLAG IS HOURLY (H). RUNS HOURLY EMPLOYEE CLASS IF SO
		{
			staff[indexCounter] = new HourlyEmployee;//ADDING HOURLY EMPLOYEE INFO TO ARRAY OF EMPLOYEE PTRS
			staff[indexCounter]->ReadData(fileIn);
			indexCounter++;//INCREMENT STAFF INDEX
			empH_counter++;//COUNTING NUM OF HOURLY EMPLOYEES
		}
		else if ( (characterFlag == 'm') || (characterFlag == 'M') )//CHECKS IF THE FLAG IS MONTHLY (M). RUNS MONTLY EMPLOYEE CLASS IF SO
		{
			staff[indexCounter] = new MonthlyEmployee;//ADDING HOURLY EMPLOYEE INFO TO ARRAY OF EMPLOYEE PTRS
			staff[indexCounter]->ReadData(fileIn);
			indexCounter++;//INCREMENT STAFF INDEX
			empM_counter++;//COUNTING NUM OF MONTHLY EMPLOYEES
		}
		else
		{//OUTPUTS ERROR MESSAGE IF ANYTHING OTHER THAN (H) OR (M) IS FOUND. WILL NOT CREATE OUTPUT FILE. INPUT FILE SHOULD BE ADJUSTED
			fileIn.close();
			cout << "Employee of unknown type dectected. File is being closed. Output file not generated." << endl;
			return 0;//USED TO EXIT MAIN IF UNKNOWN CHAR FLAG IS FOUND
		}
	}

	//IF NOT ENCOUNTER ELSE MESSAGE, DISPLAY NUM OF HOURLY/MONTHLY EMPLOYEES
	cout << "NUMBER OF HOURLY EMPLOYEES:" << endl << empH_counter << endl << endl;
	cout << "NUMBER OF MONTHLY EMPLOYEES:" << endl << empM_counter << endl << endl;
	cout << "Now saving staff information onto file. All monthly employees are listed first. Program completed." << endl << endl;

	//BEGINNING FILE OUTPUT
	ofstream fileOut;
	fileOut.open( outputFileName );
	if ( fileOut.fail() ) //PRODUCE ERROR MESSAGE IF FILE DOESNT OPEN. MAKE SURE YOU HAVE TYPED THE FILE NAME CORRECTLY/ FILE IS IN CORRECT LOCATION
	{
		cout << "Output file opening failed\n";
		return 0;
	}

	//CHECKS TO SEE IF TYPE IS MONTHLY. PRINTS MONTLY FIRST
	for ( int i = 0; i < indexCounter; ++i ) 
	{
		if ( staff[i]->GetType() == "Monthly Employee" ) 
		{
			fileOut << staff[i]->GetType() << endl;
			staff[i]->WriteData(fileOut);
		}
	}
	fileOut << endl << endl;
	//CHECKS TO SEE IF THE TYPE IS HOURLY. PRINTS AFTER HOURLY
	for ( int i = 0; i < indexCounter; ++i ) 
	{
		if (staff[i]->GetType() == "Hourly Employee") 
		{
			fileOut << staff[i]->GetType() << endl;
			staff[i]->WriteData(fileOut);
		}
	}

	fileOut.close();

	return 0;
}