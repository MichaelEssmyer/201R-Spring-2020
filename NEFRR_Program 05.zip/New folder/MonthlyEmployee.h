#include "Employee.h"
#include <string>
using namespace std;

class MonthlyEmployee : public Employee {
public:
	MonthlyEmployee();//CONSTRUCTOR
	bool setRank( int userRank );//SETTER
//VIRTUAL FUNCTION OVERRIDES
	string GetType() const;
	bool ReadData( std::istream& in ) override;//OVERRIDES EMPLOYEE VIRTUAL FUNCTION
	bool WriteData( std::ostream& out ) override;//OVERRIDES EMPLOYEE VIRTUAL FUNCTION
private:
	int rank;

};

