#include <iostream>
#include <fstream>
#include <string>
#include "MonthlyEmployee.h"

using namespace std;

MonthlyEmployee::MonthlyEmployee()//DEFAULT CONSTRUCTOR
{
	rank = 10;
}
bool MonthlyEmployee::setRank( int userRank ) //SETS USER RANK. MUST BE BETWEEN 1-10 INCLUSIVE
{
	if (userRank >= 1 && userRank <= 10) {
		rank = userRank;
		return true;
	}
	else {//IF RANK DOES NOT MEET THE ABOVE CRITERIA, DEFAULTS TO 10
		return false;
	}
}
string MonthlyEmployee::GetType() const
{
	return "Monthly Employee";
}
bool MonthlyEmployee::ReadData( std::istream& in ) //CALLS EMPLOYEE VIRTUAL FUNCTION. READS THE NAME, ID, AND RANK FROM FILE
{
	Employee::ReadData(in);
	int rank;
	in >> rank;
	setRank(rank);
	in.ignore();
	return in.good();
}
bool MonthlyEmployee::WriteData( std::ostream& out )//CALLES EMPLOYEE VIRTUAL FUNCTION. OUTPUTS FILE TO DESKTOP. 
{
	Employee::WriteData(out);
	out << rank << endl;
	return out.good();
}