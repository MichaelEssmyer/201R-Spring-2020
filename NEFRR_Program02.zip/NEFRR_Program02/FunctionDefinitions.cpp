#include <iostream>
#include <cmath>
using namespace std;

int PrintMenu() {//DISPLAYS MENU OPTION FOR USER. WILL LOOP UNTIL VALID INPUT ENTERED. RETURNS USER SELECTION
	int userSel;
	cout << "Welcome to the Paint Shop" << endl;

	cout << "Please choose from the following options:  " << endl;
	cout << "1 - Paint the interior of the house " << endl;
	cout << "2 - Paint the exterior of the house" << endl;
	cout << "3 - Paint the interior and exterior of the house" << endl;

	cin >> userSel;

	while ((userSel != 1) && (userSel != 2) && (userSel != 3)) {
		cout << "Entry Invalid." << endl;
		cout << "Please choose from the following options:  " << endl;
		cout << "1 - Paint the interior of the house " << endl;
		cout << "2 - Paint the exterior of the house" << endl;
		cout << "3 - Paint the interior and exterior of the house" << endl;

		cin >> userSel;
	}
	return userSel;
}

int numPaintCans(double AreaHouse) {//CALCULATES THE NUMBER OF PAINT CANS NEEDED FOR A JOB BASED OFF THE AREA.
	cout << "Each individual can of paint covers 400 sq feet" << endl;
	cout << "The calculated area of the walls to be painted is " << AreaHouse << " sq feet"<<endl;
	cout << "You will need " << AreaHouse / 400.00 << " can(s) of paint rounded up to " << ceil(AreaHouse / 400) << " can(s)" << endl;
	return ceil(AreaHouse / 400);
}

double AreaHouse() {//CALCULATES THE AREA OF THE HOUSE. RETURNS IT AS A DOUBLE IN CASE OF SIZES THAT ARE NOT INT.
	int numWallsPaint;
	double height;
	double width;
	int count = 0;
	double area =0;

	cout << "How many walls would you like to paint" << endl;
	cin >> numWallsPaint;

	while (count != numWallsPaint) {
		cout << "Enter the width and height for wall " << count + 1 << endl;
		cout << "Width :  ";
		cin >> width;
		cout << "Height : ";
		cin >> height;
		area += width * height;
		count++;
	}
	cout << endl << endl;
	return area;
}

void costInterior(int numPaintCans) {//CALCULATES COST OF INTERIOR. CONST COST
	const int interiorPaintCost = 100;
	cout << "Calculating the cost of painting the interior..." << endl;
	cout << "The cost of a single can of paint is $100" << endl;
	cout << "The total cost is $" <<numPaintCans * interiorPaintCost;
}

void costExterior(int numPaintCans) {//CALCULATES COST OF EXTERIOR. CONST COST
	const int exteriorPaintCost = 150;
	cout << "Calculating the cost of painting the exterior..." << endl;
	cout << "The cost of a single can of paint is $100" << endl;
	cout << "The total cost is $" << numPaintCans * exteriorPaintCost;
}

void InteriorAndExterior(int numPaintCans) {//CALCULATES COST OF BOTH. CONST COST
	const int interiorPaintCost = 100;
	const int exteriorPaintCost = 150;

	int costInterior = interiorPaintCost * numPaintCans;
	int costExterior = exteriorPaintCost * numPaintCans;
	
	cout << "Calculating the cost of painting the interior and exterior..." << endl;
	cout << "The cost of a single can of paint is $100 for the interior, $150 for the exterior" << endl;
	cout << "The total cost is $" << costInterior + costExterior;

}