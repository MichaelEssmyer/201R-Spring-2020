//NEHESIA EDMOND
//Program 2
//Due 20 February 2359

#include <iostream>
#include "functionHeader.h"
using namespace std;

//FUNCTIONS IN SEPARATE FILE FOR NEATNESS
//WORDING CHANGED TO MAKE MORE SENSE

int main() {
	int userChoice;
	userChoice = PrintMenu();

	if (userChoice == 1) {
		costInterior(numPaintCans(AreaHouse()));
	}
	else if (userChoice == 2) {
		costExterior(numPaintCans(AreaHouse()));
	}
	else {
		InteriorAndExterior(numPaintCans(AreaHouse()));
	}
	cout <<endl<<endl<< "Have a nice day.";

	return 0;
}
