double AreaHouse();
int numPaintCans(double AreaHouse);
void costInterior(int numPaintCans);
void costExterior(int numPaintCans);
void InteriorAndExterior(int numPaintCans);
int PrintMenu();