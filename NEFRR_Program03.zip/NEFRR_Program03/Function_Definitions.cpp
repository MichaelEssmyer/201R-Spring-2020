#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include<algorithm>


using namespace std;

int MainMenu() {
	int userSel;
	do {
		cout << "Welcome to the Student Center" << endl;
		cout << "1- Display Student Info" << endl;
		cout << "2- Display Student Info sorted by city" << endl;
		cout << "3- Display Student Info sorted by city and total number of students in each city" << endl;
		cout << "4- Exit" << endl;

		cout << "Please choose an option " << endl;
		cin >> userSel;
		switch (userSel)
		{
		case 1:
			//return 1;
			break;
		case 2:
			//return 1;
			break;
		case 3:
			break;
		case 4:
			cout << "Have a nice day!";
			return 4;
			break;
		default:
			cout << "Invalid selection." << endl;
		}
	} while (userSel != 1 && userSel != 2 && userSel != 3 && userSel != 4);
	return userSel;
}

void display_Info(int ID[], string first[], string last[], string city[], string state[], double GPA[], int arraySize) {
	//sortedArray []
	for (int i = 0; i < arraySize; ++i) {
		cout << ID[i] << setw(6) << right << " ";
		cout << setw(10) << right << first[i] << "   " << setw(10) << right << last[i] << "    ";
		cout << setw(15) << right << city[i] << right;
		cout << setw(10) << right << state[i] << "    " << GPA[i] << endl;
	}
}

void swap(string* xp, string* yp)
{
	string temp = *xp;
	*xp = *yp;
	*yp = temp;
}

void swap(int* xp, int* yp)
{
	int temp = *xp;
	*xp = *yp;
	*yp = temp;
}

void swap(double* xp, double* yp)
{
	double temp = *xp;
	*xp = *yp;
	*yp = temp;
}

void count_students_from_city(string city[], string state[], int size) {
	string arr3[10];
	string spacedCity;
	for (int i = 0; i < size; ++i) {
		spacedCity = "";
		for (int j = 0; j < city[i].length(); ++j) {
			if (isupper(city[i][j])) {
				spacedCity += ' ';
				spacedCity += city[i][j];
			}
			else
				spacedCity += city[i][j];
		}
		arr3[i] = spacedCity + ", " + state[i];
	}

	int n = sizeof(arr3)/ sizeof(arr3[0]);

	string testCase = " ";
	string currentCity;
	int counter;

	for (int i = 0; i < size; ++i) {//outputs city and state. Will also output count for same city name, different state (ie kcK, KCMO)
		counter = count(arr3, arr3 + n, arr3[i]);

		if ((counter >= 1) && (testCase.compare(arr3[i]) != 0)) {
			cout << "***** We have " << counter << " from " << arr3[i]<< " this year *****" << endl;
		}
		testCase = arr3[i];
		
	}
}

void display_By_City(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size) {
	int i, j;
	for (i = 0; i < size - 1; i++) {
		// Last i elements are already in place  
		for (j = 0; j < size - i - 1; j++)
		{
			if (city[j] < city[j + 1])
			{
				swap(&ID[j], &ID[j + 1]);
				swap(&first[j], &first[j + 1]);
				swap(&last[j], &last[j + 1]);
				swap(&city[j], &city[j + 1]);
				swap(&state[j], &state[j + 1]);
				swap(&GPA[j], &GPA[j + 1]);
			}
		}
	}
	cout << "The student information sorted in descending order: " << endl;
	display_Info(ID, first, last, city, state, GPA, size);
	cout << endl;
}

void RetrieveFileInfo(int studentID[], string firstName[], string lastName[], string city[], string state[], double studentGPA[], bool fileUseCheck) {
	if (!fileUseCheck) {
		cout << endl;
	}
	else {
		int i = 0;
		ifstream inFile; //Input file stream

		inFile.open("Student_Info.txt");
		if (inFile.fail()) {
			cout << "Could not open file." << endl;
		}
		while (i < 10) {
			inFile >> studentID[i] >> firstName[i] >> lastName[i] >> city[i] >> state[i] >> studentGPA[i];
			++i;
		}
		inFile.close();
	}
}