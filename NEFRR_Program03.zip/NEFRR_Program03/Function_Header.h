#include <iostream>
#include <string>
using namespace std;

int MainMenu();
void RetrieveFileInfo(int studentID[], string firstName[], string lastName[], string city[], string state[], double studentGPA[], bool fileUseCheck);
void display_Info(int ID[], string first[], string last[], string city[], string state[], double GPA[], int arraySize);//for option 1
void swap(string* xp, string* yp);//used for bubble sort
void swap(int* xp, int* yp);// used for bubble sort
void swap(double* xp, double* yp); // used for bubble sort
void count_students_from_city(string city[], string state[], int size);//for option 3 part 2
void display_By_City(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size);//for option 2, for option3 part 1
