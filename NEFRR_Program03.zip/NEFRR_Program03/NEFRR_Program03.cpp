//NEHESIA EDMOND
//PROGRAM 03
//DUE 5 MARCH 2359

#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
#include<algorithm>
#include "Function_Header.h"

using namespace std;

//NOTE THAT THE OTHER FUNCTOINS ARE IN SEPARATE FILES FOR NEATNESS

int main() {
	//Initilizing all variables. 
	const int arraySize = 10;
	int studentID[arraySize];
	string firstName[arraySize];
	string lastName[arraySize];
	string city[arraySize];
	string state[arraySize];
	double studentGPA[arraySize];
	bool fileUseCheck = true;
	int userSel = MainMenu();

	//Program will loop until the user selects 4 (quit)
	while (userSel != 4) {
		if (userSel == 1) {//displays student values sorted by ID 
			RetrieveFileInfo(studentID, firstName, lastName, city, state, studentGPA, fileUseCheck);
			display_Info(studentID, firstName, lastName, city, state, studentGPA, arraySize);
			userSel = MainMenu();
		}
		if (userSel == 2) {//displays student values sorted by city in descending order
			RetrieveFileInfo(studentID, firstName, lastName, city, state, studentGPA, fileUseCheck);
			display_By_City(studentID, firstName, lastName, city, state, studentGPA, arraySize);//Sorted order not specified so sorted in decending order Z-A
			userSel = MainMenu();
		}
		if (userSel == 3) {//displays same as 2 but includes num of students from city/state. Takes into account KCMO and KC K
			RetrieveFileInfo(studentID, firstName, lastName, city, state, studentGPA, fileUseCheck);
			display_By_City(studentID, firstName, lastName, city, state, studentGPA, arraySize);//Sorted order not specified so sorted in decending order Z-A
			count_students_from_city(city, state, arraySize);
			userSel = MainMenu();
		}
		if (userSel == 4) {//stops the lloop. Thanks the user. 
			fileUseCheck = false;
			RetrieveFileInfo(studentID, firstName, lastName, city, state, studentGPA, fileUseCheck);
			break;
		}
	}
	return 0;
}
