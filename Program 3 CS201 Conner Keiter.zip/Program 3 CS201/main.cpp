
#include  <string>
#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
//declaring all of the required functions before the main
void menu();
void display_Info(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size);
void display(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size);
void count_city(string city[], string state[], int size);


int main() {
    //declaring all the arrays
    const int size = 10;
    int ID[10];
    string first[10];
    string last[10];
    string city[10];
    string state[10];
    double GPA[10];
    //creates the in stream
    fstream fin;
    fin.open("Student_Info.txt");
    int line = 0;
    //continues to add to the arrays while the file still has data to read
    while (fin.good()) {
        fin >> ID[line];
        fin >> first[line];
        fin >> last[line];
        fin >> city[line];
        fin >> state[line];
        fin>> GPA[line];
        line++;
        
    }
    //closes the file stream
    fin.close();
    int userChoice;
    int loopCount = 0;
    //prints out the menu and has the user choose options until they want to quit
    do {
        if (loopCount > 0){
            //validates user input
            if (userChoice > 4 || userChoice <1) {
                cout << "Please input valid choice" << endl;
            }
            switch(userChoice) {
                case 1:
                    display_Info(ID, first, last, city,state, GPA, size);
                    break;
                case 2:
                    display(ID, first, last, city, state, GPA, size);
                    break;
                case 3:
                    display(ID, first, last, city, state, GPA, size);
                    count_city(city, state, size);
                    break;
                default:
                    break;
            }
        }
        menu();
        cout << "Please choose an option" << endl;
        cin >> userChoice;
        loopCount++;
    } while ( userChoice != 4);
    //goodbye message to the user when they are finished with the program
    cout << "Have a great day"<<endl;
    return 0;
}
//prints the menu out
void menu() {
    cout << "Welcome to Student Center" << endl;
    cout << "1- Display Student Info" << endl;
    cout << "2- Display Student Info sorted by City" << endl;
    cout << "3- Display Student Info sorted by City and Total number of students in each City" << endl;
    cout << "4- Exit" << endl;
}
//displays all student info in order of how the file had them
void display_Info(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size) {
    
    for (int i = 0; i < size ; i++) {
        cout << "\t" << ID[i] << "\t" << first[i] << "\t" << last[i] <<  "\t" << city[i] << "\t" << state[i] << "\t" << GPA[i] << endl;
        
    }
    cout << endl;
}
//displays student info in the order of city by alphabetical ordering
void display(int ID[], string first[], string last[], string city[], string state[], double GPA[], int size){
    int i,j;
    //bubble sort for the city name
    for (i = size-1; i > 0 ; i--){
        for (j = 0; j<i ; j++) {
            if (city[j] > city[j+1]) {
                int tempId;
                string tempFirst, tempLast, tempCity, tempstate;
                double tempGPA;
                string temp = city[j];
                
                tempId = ID[j];
                tempFirst= first[j];
                tempLast = last[j];
                tempCity = city[j];
                tempstate = state[j];
                tempGPA = GPA[j];
                
                ID[j] = ID[j+1];
                first[j] = first[j+1];
                last[j] = last[j+1];
                city[j] = city[j+1];
                state[j] = state[j+1];
                GPA[j] = GPA[j+1];
                
                ID[j+1] = tempId;
                first[j+1] = tempFirst;
                last[j+1] = tempLast;
                city[j+1] = tempCity;
                state[j+1] = tempstate;
                GPA[j+1] = tempGPA;
                
            }
        }
    }
    //print portion of the function
    for (i = 0; i < size ; i=j) {
        cout << "\t" << ID[i] << "\t" << first[i] << "\t" << last[i] <<  "\t" << city[i] << "\t" << state[i] << "\t" << GPA[i] << endl;
        for (j = i+1; j <size; j++) {
            if (city[i] == city[j]) {
                cout << "\t" << ID[j] << "\t" << first[j] << "\t" << last[j] <<  "\t" << city[j] << "\t" << state[j] << "\t" << GPA[j] << endl;
            }
            else {
                break;
            }
        }
        i=j;
    }
    
    cout <<endl;
}
//counts how many students are in each city
void count_city(string city[], string state[], int size){
    int i,j;
    //bubble sorts the city data
    for (i = size-1; i > 0 ; i--){
        for (j = 0; j<i ; j++) {
            if (city[j] > city[j+1]) {
                string temp = city[j];
                city[j] = city [j+1];
                city[j+1] = temp;
            }
        }
    }
    //printing portion of the function
    for (i = 0; i < size ; i=j) {
        int count = 1;
        for (j = i+1; j <size; j++) {
            if (city[i] == city[j]) {
                count++;
            }
            else {
                break;
            }
        }
        cout << "\t***** We have " << count << " students from " << city[i] << " this year *****" << endl;
        i=j;
    }
    cout << endl;
}
