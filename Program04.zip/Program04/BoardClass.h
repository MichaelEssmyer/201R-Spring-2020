#ifndef BOARD_H
#define BOARD_H

#include <string>
#include <array>
#include "Player.h"

using namespace std;

class Board: public Player {

public:
	void DisplayBoard();
	void CreateBoard(int num);//creates a board that is overwritten 
	void ClearBoard(); //resets constructors to default values
	char PlayerTurn(int playerNum);//checks each time it is the players turn for win conditions
	bool TileFilledCheck(int location); // checkes tile availability
	int TakenValueFix(int selectedLocation, int counter); //if tile is taken, keeps asking the player until correct value is entered
	void NameAndPiecePopulator();//populates the arrays for name and tileHolder
	void GamePlay();//The gameplay. 
	char WinCheck();//Checks win conditions
	void OutputFile();//outputs to file. File will keep appending until player quits the game

private:
	Tile tileLocation[9];
	string names[2];
	char pieceHolder[2];
	string winner[2];
};
#endif;



