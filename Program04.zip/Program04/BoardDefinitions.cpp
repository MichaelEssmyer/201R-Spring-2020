#include "BoardClass.h"
#include <iostream>
#include <fstream>
#include "Player.h"
#include <array>

using namespace std;

void Board::DisplayBoard() {	
	cout << "     |     |     " << endl;
	cout << "  " << tileLocation[0].playerPiece << "  |  " << tileLocation[1].playerPiece << "  |  " << tileLocation[2].playerPiece << endl;

	cout << "_____|_____|_____" << endl;
	cout << "     |     |     " << endl;

	cout << "  " << tileLocation[3].playerPiece << "  |  " << tileLocation[4].playerPiece << "  |  " << tileLocation[5].playerPiece << endl;;

	cout << "_____|_____|_____" << endl;
	cout << "     |     |     " << endl;

	cout << "  " << tileLocation[6].playerPiece << "  |  " << tileLocation[7].playerPiece << "  |  " << tileLocation[8].playerPiece << endl;

	cout << "     |     |     " << endl << endl;

}

void Board::ClearBoard() {
	Tile resetTile;
	for (int i = 0; i < 9; ++i) {
		tileLocation[i] = resetTile;
	}
}

void Board::NameAndPiecePopulator() {
	string player1 = GetPlayerName("1");
	string player2 = GetPlayerName("2");
	SetPlayerName(player1);
	SetPlayerName(player2);
	names[0] = player1;
	names[1] = player2;
	Tile player1Piece, player2Piece;
	player1Piece.playerPiece = 'x';
	player2Piece.playerPiece = 'o';
	pieceHolder[0] = player1Piece.playerPiece;
	pieceHolder[1] = player2Piece.playerPiece;
};

void Board::CreateBoard(int num) {	
		cout <<endl<< names[num] << "'s turn" << endl;
		DisplayBoard();
		int selectedLocation = setTileLocation();
		bool tileAvailable = TileFilledCheck(selectedLocation);

		int counter = 0;
			if (!tileAvailable) {
				selectedLocation = TakenValueFix(selectedLocation, counter);
			}
			tileLocation[selectedLocation - 1].tileLocation = selectedLocation;
			tileLocation[selectedLocation - 1].playerPiece = pieceHolder[num];
		counter++;
}

int Board::TakenValueFix(int selectedLocation, int counter) {
	int newSelectedLocation;
	do {
		cout << "That position is already taken. Please select another.";
		newSelectedLocation = setTileLocation();
	} while ( (newSelectedLocation == selectedLocation) && (counter <10) );
	return newSelectedLocation;
	
}

bool Board::TileFilledCheck(int location) {
	if (tileLocation[location - 1].playerPiece == ' ') {
		return true;
	}
	else {
		return false;
	}
}

char Board::PlayerTurn(int playerNum) {
	CreateBoard(playerNum);
	char keepPlaying = WinCheck();
	if (keepPlaying == 'x') {
		cout << names[0] << " wins!" << endl;
	}
	else if (keepPlaying == 'o') {
		cout << names[1] << " wins!" << endl;
	}
	return keepPlaying;
}

void Board::GamePlay() {
	char playAgain = 'y';	
	
	while (playAgain == 'y') {
		NameAndPiecePopulator();
		char keepPlaying = 'c';
		int counter = 0;
		while (keepPlaying == 'c') {
			keepPlaying = PlayerTurn(counter % 2);
			++counter;
			if (counter > 8) {
				cout << "Tie game" << endl;
				keepPlaying = 't';
			}
		}
		DisplayBoard();
		if (keepPlaying == 'x') {
			winner[0] = "won";
			winner[1] = "";
		}
		else if (keepPlaying == 'o') {
			winner[0] = "";
			winner[1] = "won";
		}
		else {
			winner[0] = "tie";
			winner[1] = "tie";
		}
		OutputFile();
		
		cout << "Would you like to play again?" << endl;
		cin >> playAgain;
		cin.ignore();
		playAgain = tolower(playAgain);
		if (playAgain == 'y') {
			ClearBoard();
		}
	}
}

char Board::WinCheck() {
		//figured since this was such a small array, I can brute force this. If it were larger I would take a different approach

		//horizontal win check
		if ( tileLocation[0].playerPiece != ' ' && tileLocation[0].playerPiece == tileLocation[1].playerPiece && tileLocation[1].playerPiece == tileLocation[2].playerPiece ) {
			return tileLocation[0].playerPiece;
		}
		else if ( tileLocation[3].playerPiece != ' ' && tileLocation[3].playerPiece == tileLocation[4].playerPiece && tileLocation[4].playerPiece == tileLocation[5].playerPiece) {
			return tileLocation[3].playerPiece;
		}
		else if ( tileLocation[6].playerPiece != ' ' && tileLocation[6].playerPiece == tileLocation[7].playerPiece && tileLocation[7].playerPiece == tileLocation[8].playerPiece ) {
			return tileLocation[6].playerPiece;
		}

		//vetical win check
		else if ( tileLocation[0].playerPiece != ' ' && tileLocation[0].playerPiece == tileLocation[3].playerPiece && tileLocation[3].playerPiece == tileLocation[6].playerPiece ) {
			return tileLocation[0].playerPiece;
		}
		else if ( tileLocation[1].playerPiece != ' ' && tileLocation[1].playerPiece == tileLocation[4].playerPiece && tileLocation[4].playerPiece == tileLocation[7].playerPiece) {
			return tileLocation[1].playerPiece;
		}
		else if ( tileLocation[2].playerPiece != ' ' && tileLocation[2].playerPiece == tileLocation[5].playerPiece && tileLocation[5].playerPiece == tileLocation[8].playerPiece ) {
			return tileLocation[2].playerPiece;
		}

		//diagnal win check
		else if ( tileLocation[0].playerPiece != ' ' && tileLocation[0].playerPiece == tileLocation[4].playerPiece && tileLocation[4].playerPiece == tileLocation[8].playerPiece ) {
			return tileLocation[0].playerPiece;
		}
		else if ( tileLocation[6].playerPiece != ' ' && tileLocation[6].playerPiece == tileLocation[4].playerPiece && tileLocation[4].playerPiece == tileLocation[2].playerPiece ) {
			return tileLocation[6].playerPiece;
		}

		else {
			return 'c';//returning c to indicate continue
		}
}

void Board::OutputFile() {
	ofstream fout;
	fout.open("win.txt", std::ios_base::app);
	//ofstream fout  ("win.txt");
	if (fout.fail()) {
		cout << "Output file opening failed\n";
	}
	//fout.close();

	if (fout.fail()) {
		cout << "Output file opening failed\n";
	}
	for (int i = 0; i < 2; ++i) {
		fout << names[i] << " " << winner[i] << " ";//wins[i] where win check will add wins as string for winner, blank as string for loser
	}
	fout <<endl<< "     |     |     " << endl;
	fout << "  " << tileLocation[0].playerPiece << "  |  " << tileLocation[1].playerPiece << "  |  " << tileLocation[2].playerPiece << endl;

	fout << "_____|_____|_____" << endl;
	fout << "     |     |     " << endl;

	fout << "  " << tileLocation[3].playerPiece << "  |  " << tileLocation[4].playerPiece << "  |  " << tileLocation[5].playerPiece << endl;;

	fout << "_____|_____|_____" << endl;
	fout << "     |     |     " << endl;

	fout << "  " << tileLocation[6].playerPiece << "  |  " << tileLocation[7].playerPiece << "  |  " << tileLocation[8].playerPiece << endl;

	fout << "     |     |     " << endl << endl;
	fout << endl;
	fout.close();

}



