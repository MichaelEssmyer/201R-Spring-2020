#ifndef TILE_H
#define TILE_H
#include <string>

using namespace std;

struct Tile {
	char playerPiece = ' ';
	int tileLocation = 0;
	bool TileAvailabe = true;
};

class Player {//ADD TILE CONSTRUCT. SHOULD HAVE TILE CHECK, TILE LOCATION, PLAYER MARK
public:
	string GetPlayerName(string playerNum);//Gets players names
	void SetPlayerName(string player);//setter
	int setTileLocation(); //uses the return value of getTile to set user Row and Col into char 1-9		
	int getTile(string rowWord);//Gets usesrs choice of row. Error Handling completed here
	

 private:
	 string player;
	Tile tileLocation;
	Tile playerPiece;
	Tile TileAvailable;
}; 
#endif
