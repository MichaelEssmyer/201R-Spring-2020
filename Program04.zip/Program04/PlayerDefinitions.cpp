#include <iostream>
#include <array>
#include <string>
#include <ctype.h>
#include "Player.h"

using namespace std;

string Player::GetPlayerName(string playerNum) {
	string player;
	cout << "Please enter the name for player " << playerNum<< ":" << endl;
	getline(cin, player);
	if (player == "" || player ==" ") {//default name for player if none given
		player = "player " + playerNum;
	}
	return player;

}

void Player::SetPlayerName(string player) {
	this->player = player;
}

int Player::setTileLocation() {
	int row = getTile("row");
	int col = getTile("column");
	struct Tile Tile;

	if ((row == 1) && (col == 1)) {
		return Tile.tileLocation =1;
	}
	else if ((row == 1) && (col == 2)) {
		return Tile.tileLocation = 2;
	}
	else if ((row == 1) && (col == 3)) {
		return Tile.tileLocation = 3;
	}
	else if ((row == 2) && (col == 1)) {
		return Tile.tileLocation = 4;
	}
	else if ((row == 2) && (col == 2)) {
		return Tile.tileLocation = 5;
	}
	else if ((row == 2) && (col == 3)) {
		return Tile.tileLocation = 6;
	}
	else if ((row == 3) && (col == 1)) {
		return Tile.tileLocation = 7;
	}
	else if ((row == 3) && (col == 2)) {
		return Tile.tileLocation = 8;
	}
	else if ((row == 3) && (col == 3)) {
		return Tile.tileLocation = 9;
	}
	else {
		return Tile.tileLocation = 0;
	}

}

int Player::getTile(string rowWord) {
	int userChoice;
	cout << "Enter the " << rowWord << " number (1, 2, 3)" << endl;
	cin >> userChoice;
	while (true) {
		if (cin.fail()) {
			cin.clear();
			cin.ignore(numeric_limits<streamsize>::max(), '\n');
			cout << "Invalid input recieved, must be an integer ";
		}
		else if (userChoice < 1 || userChoice > 3) {
			cout << "Value must be between 1 -3 ";
		}
		else {
			break;
		}
		cout << "Enter the " << rowWord << " number (1, 2, 3)" << endl;
		cin >> userChoice;
	}
	return userChoice;
}

