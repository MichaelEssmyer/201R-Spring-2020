#include <iostream>
#include <array>
#include "BoardClass.h"

using namespace std;

int main() {
	Board player;
	player.GamePlay();
	return 0;
}

